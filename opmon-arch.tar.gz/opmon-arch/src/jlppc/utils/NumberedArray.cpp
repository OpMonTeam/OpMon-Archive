#include "NumberedArray.hpp"
NumberedArray::NumberedArray(int number, std::string str) {
    this->number = number;
    this->attaque = str;
}
