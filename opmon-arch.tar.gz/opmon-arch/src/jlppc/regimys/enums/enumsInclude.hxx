/*
enumsInclude.hxx
Auteur : Jlppc
Fichier sous licence GPL-3.0
http://opmon-game.ga
Permet d'inclure les fichiers du dossier enums
*/
#ifndef SRCCPP_JLPPC_REGIMYS_ENUMS_ENUMSINCLUDE_HXX_
#define SRCCPP_JLPPC_REGIMYS_ENUMS_ENUMSINCLUDE_HXX_

#include "Caractere.hpp"
#include "Enums.hpp"

#endif /* SRCCPP_JLPPC_REGIMYS_ENUMS_ENUMSINCLUDE_HXX_ */
