#include "Caractere.hpp"
namespace Caractere {
    const CaractereClass *enumsList[25] = {&ASSURE, &BIZARRE, &BRAVE, &CALME, &DISCRET, &DOCILE, &DOUX, &FOUFOU, &GENTIL, &HARDI, &JOVIAL, &LACHE, &MALIN, &MALPOLI, &MAUVAIS, &MODESTE,
                                           &NAIF, &PRESSE, &PRUDENT, &PUDIQUE, &RELAX, &RIGIDE, &SERIEUX/*Why so serious?*/,&SOLO, &TIMIDE
                                          };
}

