#ifndef PERSISTENTVARS_HPP
#define PERSISTENTVARS_HPP

//TODO
namespace PersistentVars {
}
#endif // PERSISTENTVARS_HPP
