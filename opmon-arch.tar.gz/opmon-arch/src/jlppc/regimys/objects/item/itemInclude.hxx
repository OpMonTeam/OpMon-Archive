/*
itemInclude.hxx
Auteur : Jlppc
Fichier sous licence GPL-3.0
http://opmon-game.ga
Permet d'inclure tous les fichiers du dossier item
*/
#ifndef SRCCPP_JLPPC_REGIMYS_OBJECTS_ITEM_ITEMINCLUDE_HXX_
#define SRCCPP_JLPPC_REGIMYS_OBJECTS_ITEM_ITEMINCLUDE_HXX_

#include "CT.hpp"
#include "IHeal.hpp"
#include "IHeal.hpp"
#include "Item.hpp"

#endif /* SRCCPP_JLPPC_REGIMYS_OBJECTS_ITEM_ITEMINCLUDE_HXX_ */
