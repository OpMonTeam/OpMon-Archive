#include "Evolution.hpp"

Evolution::Evolution(int evo) : evo(evo) {
}

void Evolution::checkEvo() {
    //toEvolve = Initializer::listeOp[evo];
}

Espece *Evolution::getEvolution() const {
    return toEvolve;
}

