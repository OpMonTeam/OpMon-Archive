#include "evolutions.hpp"


namespace Evolutions {
    E_Land::E_Land(int evo, std::string lieu) : Evolution(evo) {

    }
}


