/*
playercoreInclude.hxx
Auteur : Jlppc
Fichier sous licence GPL-3.0
http://opmon-game.ga
Permet d'inclure tous les fichiers du dossier playercore
*/
#ifndef SRCCPP_JLPPC_REGIMYS_PLAYERCORE_PLAYERCOREINCLUDE_HXX_
#define SRCCPP_JLPPC_REGIMYS_PLAYERCORE_PLAYERCOREINCLUDE_HXX_

#include "Equipe.hpp"
#include "Player.hpp"

#endif /* SRCCPP_JLPPC_REGIMYS_PLAYERCORE_PLAYERCOREINCLUDE_HXX_ */
