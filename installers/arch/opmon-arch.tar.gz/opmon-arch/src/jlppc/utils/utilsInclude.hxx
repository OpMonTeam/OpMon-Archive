/*
utilsInclude.hxx
Author : Jlppc
Fichier sous licence GPL-3.0
http://opmon-game.ga
Permet d'inclure tout les fichiers du dossier utils
*/
#ifndef SRCCPP_JLPPC_UTILS_UTILSINCLUDE_HXX_
#define SRCCPP_JLPPC_UTILS_UTILSINCLUDE_HXX_

#include "Class.hpp"
#include "Comparaisons.hpp"
#include "File.hpp"
#include "NumberedArray.hpp"
#include "Utils.hpp"

#endif /* SRCCPP_JLPPC_UTILS_UTILSINCLUDE_HXX_ */
