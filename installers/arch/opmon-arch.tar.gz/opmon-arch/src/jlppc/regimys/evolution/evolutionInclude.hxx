/*
evolutionInclude.hxx
Author : Jlppc
Fichier sous licence GPL-3.0
http://opmon-game.ga
Permet d'inclure tous les fichiers du dossier evolution
*/
#ifndef SRCCPP_JLPPC_REGIMYS_EVOLUTION_EVOLUTIONINCLUDE_HXX_
#define SRCCPP_JLPPC_REGIMYS_EVOLUTION_EVOLUTIONINCLUDE_HXX_

#include "Evolution.hpp"
#include "evolutions.hpp"




#endif /* SRCCPP_JLPPC_REGIMYS_EVOLUTION_EVOLUTIONINCLUDE_HXX_ */
