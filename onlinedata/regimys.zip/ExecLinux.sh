java -jar Regimys.jar
pause
