java -jar Regimys.jar --creator pokemon
pause
